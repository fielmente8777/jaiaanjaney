import type {
  EnquirySectionType,
  FeatureColumnsType,
  NoticeStripType,
  SplitSectionType,
  StatementBannerType,
} from "@/@types/commonSections";
import type { HeroType } from "@/@types/homePage";

interface WeddingsPageDataType {
  hero: HeroType;
  intro: SplitSectionType;
  ceremonies: FeatureColumnsType;
  notice: NoticeStripType;
  villas: SplitSectionType;
  banner: StatementBannerType;
  enquiry: EnquirySectionType;
}

// NOTE: the Figma export was too small to read, so every label and sentence below is a
// placeholder written from the layout — replace with the final copy.
export const weddingsPageData: WeddingsPageDataType = {
  hero: {
    eyebrow: "Sacred Vows, Grand Celebrations",
    title: "Weddings at Jai Anjaney",
    description:
      "Pheras blessed beside a temple town, celebrations across lawns and chandeliered halls, and every guest staying on one estate.",
    images: ["/weddings/hero.jpg"],
  },

  intro: {
    eyebrow: "Residential & Non-Residential",
    title: "One Estate, Every Ceremony",
    description: [
      "Residential and non-residential celebrations across 151 rooms, banquet halls, open lawns and an on-site temple for pre-wedding rituals.",
      "Families arrive, settle into rooms and villas, and never need to leave: haldi on the lawn, sangeet under the chandeliers, pheras at the mandap and a reception beneath the stars.",
    ],
    image: "/weddings/intro.jpg",
    imageAlt: "A bride at her wedding at Jai Anjaney",
    highlights: [
      "151 rooms & villa rooms for guests",
      "On-site mandir for pujas",
      "Pure vegetarian catering",
      "Golf carts for elders",
    ],
    cta: { text: "Plan your wedding", link: "#enquiry" },
  },

  ceremonies: {
    eyebrow: "The Celebration",
    title: "Four Ceremonies, One Sacred Ground",
    items: [
      { label: "Day One", title: "Haldi & Mehendi", description: "Bright afternoons on Party Lawn II, with music and marigolds." },
      { label: "Day One · Evening", title: "Sangeet", description: "Dance floors and chandeliers in the Grand Banquet Hall." },
      { label: "Day Two", title: "Pheras", description: "Vows at the open-air mandap, among water and lamplight." },
      { label: "Day Two · Night", title: "Reception", description: "Dinner for up to a thousand across the lawns." },
    ],
    footnote: "जय श्री बालाजी",
  },

  notice: {
    text: "Please note: dates are confirmed on receipt of the booking advance. Speak to our wedding team for peak-season availability.",
  },

  villas: {
    eyebrow: "For the Families",
    title: "Villas for the Wedding Party",
    description: [
      "Give each family its own address: eighteen villas in a quiet garden quarter, from Silver and Gold to the Diamond Villas with plunge pools — and two Presidential Villas for the guests of honour.",
    ],
    quote: "Room blocks for the baraat, villas for the families, and a suite for the couple.",
    image: "/weddings/villas.jpg",
    imageAlt: "A villa at Jai Anjaney",
    imageShape: "arch",
    imagePosition: "right",
    cta: { text: "Explore villas", link: "/rooms-and-suites" },
    ctaVariant: "link",
  },

  banner: {
    title: "Grand Ho Toh Jai Anjaney Ho.",
    subtitle :"Celebrate At Jai Anjaney",
  },

  enquiry: {
    id: "enquiry",
    eyebrow: "Begin here",
    title: "Plan Your Wedding",
    description:
      "Tell us about your celebration and our wedding team will reply with a tailored proposal within one working day.",
    image: "/weddings/enquiry.jpg",
    imageCaption: "Where every rite feels like home",
    fields: [
      { label: "Full name", name: "name", autoComplete: "name", required: true },
      { label: "Phone", name: "phone", type: "tel", autoComplete: "tel", required: true },
      { label: "Email", name: "email", type: "email", autoComplete: "email", required: true },
      { label: "Wedding date", name: "date", type: "date" },
      {
        as: "select",
        label: "Ceremony",
        name: "ceremony",
        placeholder: "Select",
        required: true,
        options: ["Full wedding", "Mehendi / Haldi", "Sangeet", "Pheras", "Reception"],
      },
      {
        as: "select",
        label: "Guests",
        name: "guests",
        placeholder: "Select",
        required: true,
        options: ["Up to 100", "100–250", "250–400", "400–600", "600+"],
      },
      {
        as: "textarea",
        label: "Your wedding",
        name: "message",
        placeholder: "Preferred dates, number of rooms, anything we should know",
        className: "sm:col-span-2",
      },
    ],
    submitLabel: "Request a proposal",
    successMessage: "Thank you. Our wedding team will get back to you within one working day.",
    errorMessage: "We couldn't send your request. Please try again or call us.",
    phoneLabel: "Prefer to talk?",
    phone: "+91 12345 12345",
    endpoint: "",
  },
};

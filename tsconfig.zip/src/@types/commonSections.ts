import type { CtaLink } from "@/@types/galleryPage";
import type { FormFieldProps } from "@/components/Forms/FormField";

/* Types for the reusable page sections in components/CommonComponents. */

export interface StatementBannerType {
  title: string;
  subtitle?: string;
}

export interface SplitSectionType {
  eyebrow: string;
  title: string;
  description: string[];
  image: string;
  imageAlt?: string;
  /** `plain` = photo · `arch` = photo with the thin arch outline (see ArchFrame). */
  imageShape?: "plain" | "arch";
  /** Desktop side for the photo. Mobile always shows the photo first. */
  imagePosition?: "left" | "right";
  /** Short ticks shown in two columns under the copy. */
  highlights?: string[];
  /** Italic pull-quote under the copy. */
  quote?: string;
  cta?: CtaLink;
  /** `button` = filled button · `link` = underlined arrow link. */
  ctaVariant?: "button" | "link";
}

export interface FeatureColumnsType {
  eyebrow: string;
  title: string;
  items: { label: string; title: string; description: string }[];
  /** Small centred line under the columns. */
  footnote?: string;
}

export interface NoticeStripType {
  text: string;
}

export interface EnquirySectionType {
  /** Anchor id, so a CTA can link to `#<id>`. */
  id?: string;
  eyebrow: string;
  title: string;
  description: string;
  image: string;
  imageCaption: string;
  /** Plain data (serialisable), rendered in order by FormField. */
  fields: FormFieldProps[];
  submitLabel: string;
  successMessage: string;
  errorMessage: string;
  phoneLabel: string;
  phone: string;
  /** POST target for the form (JSON body). Leave empty until the endpoint exists. */
  endpoint?: string;
}

import type {
  EnquirySectionType,
  FeatureColumnsType,
  NoticeStripType,
  SplitSectionType,
  StatementBannerType,
} from "@/@types/commonSections";
import type { HeroType } from "@/@types/homePage";

interface WeddingsPageDataType {
  hero: HeroType;
  intro: SplitSectionType;
  ceremonies: FeatureColumnsType;
  notice: NoticeStripType;
  villas: SplitSectionType;
  banner: StatementBannerType;
  enquiry: EnquirySectionType;
}

// NOTE: the Figma export was too small to read, so every label and sentence below is a
// placeholder written from the layout — replace with the final copy.
export const weddingsPageData: WeddingsPageDataType = {
  hero: {
    title: "Weddings at Jai Anjaney",
    description:
      "One estate for every ceremony, from the first haldi to the last vidaai, with rooms, villas and lawns for the whole family.",
    images: ["/weddings/hero.jpg"],
  },

  intro: {
    eyebrow: "Celebrate with us",
    title: "One Estate, Every Ceremony",
    description: [
      "From the mehendi on the lawn to the pheras under the open sky, every ceremony of your wedding can unfold within one sacred, secure estate.",
      "A dedicated wedding team plans each detail with you, so the family can be guests at their own celebration.",
    ],
    image: "/weddings/intro.jpg",
    imageAlt: "A bride at her wedding at Jai Anjaney",
    highlights: [
      "500–600 guest banquet hall",
      "Open-air lawns & theatre",
      "151 rooms and villas",
      "In-house decor & catering",
    ],
    cta: { text: "Plan your wedding", link: "#enquiry" },
  },

  ceremonies: {
    eyebrow: "The ceremonies",
    title: "Four Ceremonies, One Sacred Ground",
    items: [
      { label: "01 · Pre-wedding", title: "Mehendi & Haldi", description: "Sunlit lawns, marigold and music for the first celebrations." },
      { label: "02 · Evening", title: "Sangeet", description: "An open-air theatre and ballroom made for a night of dance." },
      { label: "03 · The vows", title: "Pheras", description: "A mandap under the open sky, a short walk from every room." },
      { label: "04 · Reception", title: "Grand Banquet", description: "A pillarless ballroom that seats the whole extended family." },
    ],
    footnote: "जय श्री बालाजी",
  },

  notice: {
    text: "Please note: dates are confirmed on receipt of the booking advance. Speak to our wedding team for peak-season availability.",
  },

  villas: {
    eyebrow: "Stay together",
    title: "Villas for the Wedding Party",
    description: [
      "Private villas keep the families close and the celebrations private, with courtyards for the quiet moments between rituals.",
    ],
    quote: "Rest here for the festival; relax for the families; and for the couple.",
    image: "/weddings/villas.jpg",
    imageAlt: "A villa at Jai Anjaney",
    imageShape: "arch",
    imagePosition: "right",
    cta: { text: "Explore villas", link: "/rooms-and-suites" },
    ctaVariant: "link",
  },

  banner: {
    title: "Where Every Rite Finds Its Place",
  },

  enquiry: {
    id: "enquiry",
    eyebrow: "Begin here",
    title: "Plan Your Wedding",
    description:
      "Tell us about your celebration and our wedding team will reply with a tailored proposal within one working day.",
    image: "/weddings/enquiry.jpg",
    imageCaption: "Where every rite feels like home",
    fields: [
      { label: "Full name", name: "name", autoComplete: "name", required: true },
      { label: "Phone", name: "phone", type: "tel", autoComplete: "tel", required: true },
      { label: "Email", name: "email", type: "email", autoComplete: "email", required: true },
      { label: "Wedding date", name: "date", type: "date" },
      {
        as: "select",
        label: "Ceremony",
        name: "ceremony",
        placeholder: "Select",
        required: true,
        options: ["Full wedding", "Mehendi / Haldi", "Sangeet", "Pheras", "Reception"],
      },
      {
        as: "select",
        label: "Guests",
        name: "guests",
        placeholder: "Select",
        required: true,
        options: ["Up to 100", "100–250", "250–400", "400–600", "600+"],
      },
      {
        as: "textarea",
        label: "Your wedding",
        name: "message",
        placeholder: "Preferred dates, number of rooms, anything we should know",
        className: "sm:col-span-2",
      },
    ],
    submitLabel: "Request a proposal",
    successMessage: "Thank you. Our wedding team will get back to you within one working day.",
    errorMessage: "We couldn't send your request. Please try again or call us.",
    phoneLabel: "Prefer to talk?",
    phone: "+91 12345 12345",
    endpoint: "",
  },
};
